package com.marijannovak.autismhelper.common.enums

enum class Emotions {
    Happy, Sad, Excited, Surprised, Scared, Angry
}