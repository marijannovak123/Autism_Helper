package com.marijannovak.autismhelper.common.enums

/**
 * Created by Marijan on 23.3.2018..
 */
enum class Status {
    LOADING, SUCCESS, MESSAGE, SIGNEDUP, SAVED, NEXT, HOME, SYNCING, PROGRESS_UPDATE
}